class Sprite {
  constructor(name) {
    this.name = name;
    this.w = 100;
    this.h = 250;
  }
}